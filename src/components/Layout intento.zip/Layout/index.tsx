import React from 'react'
import { Layout as AntdLayout } from 'antd'
import Header from './Header'
import Sidebar from './Sidebar'
type LayoutProps = {
  children: React.ReactNode
}

const Layout = ({ children }: LayoutProps) => {
  const sideBar = () => {
    ;<Sidebar
      email={'email'}
      name={'nombre'}
      secondName={'Apellido'}
      NIF={'123'}
      role={1}
      className="header"
    />
  }
  return (
    <AntdLayout>
      <AntdLayout>
        <Header sideBar={sideBar} className="header" />
      </AntdLayout>
      {sideBar}
      <div>{children}</div>
    </AntdLayout>
  )
}

export default Layout
