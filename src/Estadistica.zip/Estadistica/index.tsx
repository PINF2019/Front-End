import React from 'react'
import { Row, Typography, Table, Col, Card } from 'antd'
import { Bar, Pie } from 'ant-design-pro/lib/Charts'
import 'ant-design-pro/dist/ant-design-pro.css'


// import { useElectionNameQuery } from '@Generated/hooks'

const { Text } = Typography

const columns = [
  {
    headerStyle: {textAlign: 'center'},
    title: 'CANDIDATO',
    dataIndex: 'candidato',
    key: 'candidato'
  },
  {
    title: 'PDVP',
    dataIndex: 'pdvp',
    key: 'pdvp'
  },
  {
    title: 'PNDVP',
    dataIndex: 'pndvp',
    key: 'pndvp'
  },
  {
    title: 'PDINVP',
    key: 'pdnivp',
    dataIndex: 'pdnivp'
  },
  {
    title: 'PAS',
    key: 'pas',
    dataIndex: 'pas'
  },
  {
    title: 'ALU',
    key: 'alu',
    dataIndex: 'alu'
  },
  {
    title: 'TOTAL',
    key: 'total',
    dataIndex: 'total'
  },
  {
    title: '% FINAL',
    key: 'final',
    dataIndex: 'final'
  }
];

const datatable = [
  {
    key: '1',
    candidato: 'López Cala, kevin ',
    pdvp: 'x',
    pndvp: 'y',
    pdnivp: 'z',
    pas: 'w',
    alu: 'ñ',
    total: 'm',
    final: '52,48%'
  },
  {
    key: '2',
    candidato: 'Escribano Corrales, Raúl',
    pdvp: 'x',
    pndvp: 'y',
    pdnivp: 'z',
    pas: 'w',
    alu: 'ñ',
    total: 'm',
    final: '29,70%'
  },
  {
    key: '3',
    candidato: 'Soriano Roldán, Claudia',
    pdvp: 'x',
    pndvp: 'y',
    pdnivp: 'z',
    pas: 'w',
    alu: 'ñ',
    total: 'm',
    final: '17,82%'
  }
]

const data = [
  { x: 'López Cala, kevin   ', y: 5300 },
  { x: 'Escribano Corrales, Raúl   ', y: 3000 },
  { x: 'Soriano Roldán, Claudia   ', y: 1800 }
]

const Estadisticos = () => {
  return (

    <section id="target-pacing">



      <Row style={{ marginTop: '1%', marginBottom: '1%' }}>
        <Text strong style={{ fontSize: '20px' }}>
          Resultados de elección Delegados/as
          <br />
        </Text>{' '}
        <Text style={{ textAlign: 'center', margin: 'auto' }}>
          <br />
          {new Date().toLocaleDateString()} -{new Date().toLocaleDateString()}
        </Text>
      </Row>
      <Text strong style={{ fontSize: '15px', position: 'static' }}>
        Datos globales <br />
        <br />
        <div>
    <Row>
      <Col span={4}>Número total de electores:</Col>
      <Col span={4}>23399</Col>
    </Row>
    <Row>
      <Col span={4}>Votos a candidaturas:</Col>
      <Col span={4}>6562</Col>
    </Row>
    <Row>
      <Col span={4}>Votos en blanco:</Col>
      <Col span={4}>79</Col>
    </Row>
    <Row>
      <Col span={4}>votos nulos:</Col>
      <Col span={4}>103</Col>
    </Row>
    <Row>
      <Col span={4}>Votos totales válidos:</Col>
      <Col span={4}>6641</Col>
    </Row>
    <Row>
      <Col span={4}>Participación:</Col>
      <Col span={4}>28,28%</Col>
    </Row>
    <Row>
      <Col span={4}>Abstención:</Col>
      <Col span={4}>71,18%</Col>
    </Row>
  </div>
      </Text>{' '}
      <Text
        strong
        style={{
          fontSize: '15px',
          textAlign: 'left',
          position: 'static',
          paddingTop: '10px'
        }}>
      </Text>{' '}
      <Row>
        <br />
        <Table
          style={{ width: 700}}          
          columns={columns}
          
          dataSource={datatable}
          pagination={false}
          bordered
          
        />
        <br />
      </Row>
      <br />
      <br />
      <Card type="inner">
        <Row>
          <Col span={12}>
            <Bar style={{}} height={300} title="Total votos" data={data} />
          </Col>
          <Col
            span={12}
            style={{
              borderLeft: '1px solid #F0F2F5',
              paddingLeft: 24
            }}>
            <Pie
              hasLegend
              title="Votos"
              subTitle="Votos"
              total={() => (
                <span
                  dangerouslySetInnerHTML={{
                    __html: data.reduce(
                      (pre: any, now: { y: any }) => now.y + pre,
                      0
                    )
                  }}
                />
              )}
              data={data}
              valueFormat={val => (
                <span dangerouslySetInnerHTML={{ __html: val }} />
              )}
              height={256}
            />
          </Col>
        </Row>
      </Card>
    </section>
  )
}

export default Estadisticos
